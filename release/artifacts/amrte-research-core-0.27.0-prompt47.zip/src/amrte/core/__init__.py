"""Authoritative AMRTE core services."""

